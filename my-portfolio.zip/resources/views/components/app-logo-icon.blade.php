<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" {{ $attributes }}>
    <defs>
        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#3b82f6" />
            <stop offset="100%" stop-color="#8b5cf6" />
        </linearGradient>
    </defs>
    <path fill="url(#gradient)" fill-rule="evenodd" clip-rule="evenodd" d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
</svg>
